
# # Decision Tree Model
# file1 = open('pkl/model1.pkl', 'wb') 
# pickle.dump(clf1, file1)
# file1.close()

# # SVM Model
# file2 = open('pkl/model2.pkl', 'wb') 
# pickle.dump(clf2, file2)
# file2.close()